import os

directory = "manual/cert"
for filename in os.listdir(directory):
    if "dtml" in filename:
        os.system("mv " + directory + "/" + filename + " " + directory + "/" + filename + ".bak")
        os.system("iconv -f iso-8859-1 -t utf-8 " + directory + "/" 
                + filename + ".bak" + " > " + directory + "/" + filename)
